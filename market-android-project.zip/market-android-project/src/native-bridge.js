import { NativeBiometric } from '@capgo/capacitor-native-biometric';

let biometricAvailable = false;
let checking = false;

async function refreshBiometricButton() {
  const button = document.getElementById('lockBiometric');
  const screen = document.getElementById('securityScreen');
  if (!button || !screen || checking) return;
  button.hidden = true;
  const isLogin = screen.classList.contains('show') &&
    document.getElementById('lockTitle')?.textContent === 'البرنامج محمي';
  if (!isLogin || !window.Capacitor?.isNativePlatform?.()) return;

  checking = true;
  try {
    const result = await NativeBiometric.isAvailable();
    biometricAvailable = !!result.isAvailable;
    button.hidden = !biometricAvailable;
  } catch {
    biometricAvailable = false;
    button.hidden = true;
  } finally {
    checking = false;
  }
}

window.unlockWithBiometric = async function () {
  const button = document.getElementById('lockBiometric');
  const error = document.getElementById('lockError');
  if (!biometricAvailable) {
    await refreshBiometricButton();
    if (!biometricAvailable) {
      if (error) error.textContent = 'البصمة غير متاحة حاليًا. استخدم رقم PIN أو كلمة المرور.';
      return;
    }
  }
  if (button) button.disabled = true;
  try {
    await NativeBiometric.verifyIdentity({
      reason: 'فتح دفتر ديون الماركت',
      title: 'التحقق من الهوية',
      subtitle: 'استخدم بصمة الإصبع لفتح البرنامج',
      description: 'بيانات الماركت محمية على هذا الجهاز',
      negativeButtonText: 'استخدام PIN',
      maxAttempts: 3
    });
    window.unlockApp?.();
  } catch {
    if (error) error.textContent = 'لم يتم التحقق بالبصمة. يمكنك استخدام PIN أو كلمة المرور.';
  } finally {
    if (button) button.disabled = false;
  }
};

const securityScreen = document.getElementById('securityScreen');
if (securityScreen) {
  new MutationObserver(refreshBiometricButton).observe(securityScreen, {
    attributes: true,
    attributeFilter: ['class']
  });
}
window.addEventListener('pageshow', refreshBiometricButton);
refreshBiometricButton();
