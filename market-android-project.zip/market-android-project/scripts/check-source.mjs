import { readFile } from 'node:fs/promises';
const html = await readFile(new URL('../source/index.html', import.meta.url), 'utf8');
const scripts = [...html.matchAll(/<script\b(?![^>]*\bsrc=)[^>]*>([\s\S]*?)<\/script>/gi)].map(m => m[1]);
let errors = 0;
for (let i = 0; i < scripts.length; i++) {
  try { new Function(scripts[i]); }
  catch (e) { errors++; console.error(`Inline script ${i + 1}: ${e.message}`); }
}
if (errors) process.exit(1);
console.log(`Syntax check passed for ${scripts.length} inline script blocks.`);
