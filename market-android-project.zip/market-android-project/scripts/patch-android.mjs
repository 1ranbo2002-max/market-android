import { readFile, writeFile, mkdir, copyFile } from 'node:fs/promises';
import path from 'node:path';
const root = process.cwd();
const file = path.join(root, 'android/app/src/main/AndroidManifest.xml');
let xml = await readFile(file, 'utf8');
const permissions = [
  'android.permission.INTERNET',
  'android.permission.CAMERA',
  'android.permission.USE_BIOMETRIC'
];
for (const permission of permissions) {
  const line = `    <uses-permission android:name="${permission}" />`;
  if (!xml.includes(`android:name="${permission}"`)) {
    xml = xml.replace('<application', `${line}\n    <application`);
  }
}
if (!xml.includes('android.hardware.camera')) {
  xml = xml.replace('<application', '    <uses-feature android:name="android.hardware.camera" android:required="false" />\n    <application');
}
if (!xml.includes('android:icon=')) xml = xml.replace('<application', '<application android:icon="@mipmap/ic_launcher" android:roundIcon="@mipmap/ic_launcher"');
await writeFile(file, xml, 'utf8');

const res = path.join(root, 'android/app/src/main/res');
for (const folder of ['mipmap-mdpi','mipmap-hdpi','mipmap-xhdpi','mipmap-xxhdpi','mipmap-xxxhdpi','drawable-nodpi','mipmap-anydpi-v26','values']) {
  await mkdir(path.join(res, folder), { recursive: true });
  const src = path.join(root, 'android-res', folder);
  const files = folder === 'values' ? ['colors.xml'] : folder === 'mipmap-anydpi-v26' ? ['ic_launcher.xml'] : folder === 'drawable-nodpi' ? ['ic_launcher_foreground.png'] : ['ic_launcher.png'];
  for (const name of files) await copyFile(path.join(src, name), path.join(res, folder, name));
}
console.log('Android camera, biometric permissions and launcher icon configured.');
