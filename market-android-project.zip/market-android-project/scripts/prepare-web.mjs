import { mkdir, readFile, writeFile, copyFile } from 'node:fs/promises';
import { build } from 'esbuild';
import { createRequire } from 'node:module';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const www = path.join(root, 'www');
await mkdir(path.join(www, 'vendor'), { recursive: true });
let html = await readFile(path.join(root, 'source', 'index.html'), 'utf8');
html = html.replace(
  '<script src="https://cdn.jsdelivr.net/npm/jsqr@1.4.0/dist/jsQR.js"></script>',
  '<script src="./vendor/jsQR.js"></script>'
);
const biometricButton = '<button id="lockBiometric" type="button" class="secondary" onclick="unlockWithBiometric()" hidden>🔐 فتح بالبصمة</button>';
html = html.replace(
  '<div class="security-actions"><button id="lockSubmit"',
  '<div class="security-actions">' + biometricButton + '<button id="lockSubmit"'
);
html = html.replace('</body>', '<script type="module" src="./native-bridge.js"></script>\n</body>');
await writeFile(path.join(www, 'index.html'), html, 'utf8');
const require = createRequire(import.meta.url);
const jsqrPath = require.resolve('jsqr/dist/jsQR.js');
await copyFile(jsqrPath, path.join(www, 'vendor', 'jsQR.js'));
await build({
  entryPoints: [path.join(root, 'src', 'native-bridge.js')],
  bundle: true,
  format: 'esm',
  platform: 'browser',
  target: ['es2020'],
  outfile: path.join(www, 'native-bridge.js'),
  minify: true
});
console.log('Prepared www/ from the preserved original HTML.');
